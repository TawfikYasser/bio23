#!/bin/bash

# Check if the user provided enough arguments
if [ $# -lt 3 ]; then
    echo "Usage: $0 <db> <accession_number> <num_alignments> <msa_algorithm>"
    echo "msa_algorithm options: mft (MAFFT), clo (Clustal Omega)"
    exit 1
fi

# Access the values of db, accession, num_alignments, and msa_algorithm as command-line arguments
db=$1
accession_number=$2
num_alignments=$3
msa_algorithm=$4

# Trim leading and trailing whitespaces from the accession number
accession_number=$(echo "$accession_number" | xargs)

# Specify the output directory
output_directory="/home/tawfik/SSDData/NU/Research/Courses/BIO/BIOPROJECT/BIO23/AUTOMATION"

# Step 1: Search for the sequence in NCBI using the provided accession number
echo "Searching for the sequence with accession number: $accession_number in database $db"
url="https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=$db&id=$accession_number&rettype=fasta&retmode=text"

# Use the "curl" command to fetch the data and save it directly to the desired path
if curl --fail -o "$output_directory/$accession_number.fasta" $url; then
  echo "Sequence $accession_number retrieved from database $db and saved to $output_directory/$accession_number.fasta"
else
  echo "Error: Unable to retrieve sequence $accession_number from database $db. Please check that the accession number and database name are correct."
  exit 1
fi

# Step 2: Perform Pairwise Sequence Alignment using BLAST+
echo "Performing Pairwise Sequence Alignment using BLAST+"
blastn -query "$output_directory/$accession_number.fasta" -db nt -outfmt '7' -remote -num_alignments "$num_alignments" > alignment_results.txt

# Check if the alignment_results.txt file is empty
if [ ! -s "alignment_results.txt" ]; then
  echo "Error: BLAST+ did not return any results. Check the input sequence and try again."
  exit 1
fi

# Step 3: Retrieve similar sequences based on the identifiers obtained from BLAST using curl
echo "Retrieving similar sequences from BLAST results"
cut -f2 alignment_results.txt | while read -r seqid; do
  seq_url="https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=$db&id=$seqid&rettype=fasta&retmode=text"
  curl --silent "$seq_url" >> similar_sequences.fasta
done

# Step 4: Perform Multiple Sequence Alignment using the specified algorithm
echo "Performing Multiple Sequence Alignment using $msa_algorithm"
if [ "$msa_algorithm" = "mft" ]; then
  mafft --auto similar_sequences.fasta > msa.fasta
elif [ "$msa_algorithm" = "clo" ]; then
  clustalo -i similar_sequences.fasta -o msa.fasta
else
  echo "Error: Invalid MSA algorithm specified. Supported options are 'mft' (MAFFT) and 'clo' (Clustal Omega)."
  exit 1
fi

# Check if the msa.fasta file is empty
if [ ! -s "msa.fasta" ]; then
  echo "Error: MSA produced an empty alignment file. Check the input sequence and try again."
  exit 1
fi

# Step 5: Remove duplicate sequence identifiers from the alignment
echo "Removing duplicate sequence identifiers from the alignment"
awk '/^>/{if($0 in a){i++}else{a[$0];print}}{if(i){print ">"$0; i=0}else{print}}' msa.fasta > msa_no_duplicates.fasta

# Step 6: Draw the Phylogenetic Tree using MUSCLE, PhyML, and TreeVis.py
echo "Drawing the Phylogenetic Tree using MUSCLE and PhyML"
muscle -in msa_no_duplicates.fasta -out muscle.refined.phylip -refine -phyi
phyml -i muscle.refined.phylip -d nt -m GTR -o tlr

# Check if the PhyML output file exists
if [ ! -s "muscle.refined.phylip_phyml_tree.txt" ]; then
  echo "Error: PhyML did not produce the expected output file. Check the input sequence and try again."
  exit 1
fi

# Call TreeVis.py and pass the PhyML output file to it
echo "Calling TreeVis.py for visualization"
python3 TreeVis.py muscle.refined.phylip_phyml_tree.txt

echo "All tasks completed successfully!"

