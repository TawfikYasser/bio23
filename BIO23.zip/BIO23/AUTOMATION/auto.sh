#!/bin/bash

# Check if the user provided enough arguments
if [ $# -lt 4 ]; then
    echo "Usage: $0 <db> <accession_number> <num_alignments> <msa_algorithm>"
    echo "msa_algorithm options: mft (MAFFT), clo (Clustal Omega)"
    exit 1
fi

# Access the values of db, accession, num_alignments, and msa_algorithm as command-line arguments
db=$1
accession_number=$2
num_alignments=$3
msa_algorithm=$4

# Trim leading and trailing whitespaces from the accession number
accession_number=$(echo "$accession_number" | xargs)

# Specify the output directory (can be made configurable or use relative paths)
output_directory="/home/tawfik/SSDData/NU/Research/Courses/BIO/BIOPROJECT/BIO23/AUTOMATION"

# Step 1: Search for the sequence in NCBI using the provided accession number
echo "Searching for the sequence with accession number: $accession_number in database $db"
url="https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=$db&id=$accession_number&rettype=fasta&retmode=text"

# Use the "curl" command to fetch the data and save it directly to the desired path
if curl --fail -o "$output_directory/$accession_number.fasta" "$url"; then
  echo "Sequence $accession_number retrieved from database $db and saved to $output_directory/$accession_number.fasta"
else
  echo "Error: Unable to retrieve sequence $accession_number from database $db. Please check that the accession number and database name are correct."
  exit 1
fi

# Step 2: Perform Pairwise Sequence Alignment using BLAST+
echo "Performing Pairwise Sequence Alignment using BLAST+"
blastn -query "$output_directory/$accession_number.fasta" -db nt -outfmt '7' -remote -num_alignments "$num_alignments" > "$output_directory/alignment_results.txt"

# Step 3: Check if the alignment_results.txt file exists and is non-empty
if [ -s "$output_directory/alignment_results.txt" ]; then
  # Retrieve subject accession numbers from the alignment results
  subject_accessions=$(grep -E '^\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+' "$output_directory/alignment_results.txt" | cut -f2)

  # Step 4: Check if the similar_sequences.fasta file exists and is non-empty
  if [ -s "$output_directory/similar_sequences.fasta" ]; then
    # Remove non-standard characters (U, @, #, etc) from the retrieved sequences
    sed -i '/^>/!s/[^ACGTNacgtn]//g' "$output_directory/similar_sequences.fasta"

    # Step 5: Perform Multiple Sequence Alignment using the specified algorithm
    echo "Performing Multiple Sequence Alignment using $msa_algorithm"
    if [ "$msa_algorithm" = "mft" ]; then
      mafft --auto "$output_directory/similar_sequences.fasta" > "$output_directory/msa.fasta"
    elif [ "$msa_algorithm" = "clo" ]; then
      clustalo -i "$output_directory/similar_sequences.fasta" -o "$output_directory/msa.fasta"
    else
      echo "Error: Invalid MSA algorithm specified. Supported options are 'mft' (MAFFT) and 'clo' (Clustal Omega)."
      exit 1
    fi

    # Check if the msa.fasta file is empty
    if [ ! -s "$output_directory/msa.fasta" ]; then
      echo "Error: MSA produced an empty alignment file. Check the input sequence and try again."
      exit 1
    fi

    # Step 6: Remove duplicate sequence identifiers from the alignment
    echo "Removing duplicate sequence identifiers from the alignment"
    awk '/^>/{if($0 in a){i++}else{a[$0];print}}{if(i){print ">"$0; i=0}else{print}}' "$output_directory/msa.fasta" > "$output_directory/msa_no_duplicates.fasta"

    # Step 7: Draw the Phylogenetic Tree using MUSCLE, PhyML, and TreeVis.py
    echo "Drawing the Phylogenetic Tree using MUSCLE and PhyML"
    muscle -in "$output_directory/msa_no_duplicates.fasta" -out "$output_directory/muscle.refined.phylip" -refine -phyi
    phyml -i "$output_directory/muscle.refined.phylip" -d nt -m GTR -o tlr

    # Check if the PhyML output file exists
    if [ ! -s "$output_directory/muscle.refined.phylip_phyml_tree.txt" ]; then
      echo "Error: PhyML did not produce the expected output file. Check the input sequence and try again."
      exit 1
    fi

    # Step 8: Call TreeVis.py and pass the PhyML output file to it
    echo "Calling TreeVis.py for visualization"
    python3 "$output_directory/TreeVis.py" "$output_directory/muscle.refined.phylip_phyml_tree.txt"

    echo "All tasks completed successfully!"
  else
    echo "Error: The similar_sequences.fasta file is missing or empty. Please make sure that sequences similar to the query are retrieved successfully."
    exit 1
  fi
else
  echo "Error: The alignment_results.txt file is missing or empty. Please make sure that BLAST search and alignment are completed successfully."
  exit 1
fi
