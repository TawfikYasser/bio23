#!/bin/bash
# Access the values of db and accession as command-line arguments
db=$1
accession=$2

# Specify the output directory
output_directory="/home/tawfik/SSDData/NU/Research/Courses/BIO/BIOPROJECT/BIO23/NCBI"

# Build the URL to retrieve the sequence in FASTA format from the NCBI E-utilities API
url="https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=$db&id=$accession&rettype=fasta&retmode=text"

# Use the "curl" command to fetch the data and save it directly to the desired path
if curl --fail -o "$output_directory/$accession.fasta" $url; then
  # Print a message indicating the sequence has been retrieved and saved
  echo "Sequence $accession retrieved from database $db and saved to $output_directory/$accession.fasta"
else
  # Print an error message if the URL is missing or invalid
  echo "Error: Unable to retrieve sequence $accession from database $db. Please check that the accession number and database name are correct."
fi

